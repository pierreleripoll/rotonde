## How to make a release and deploy

- Update version number in `src/color-thief.js` and `package.json`
- Run `grunt build`
- Push to Github repo
- Create a new Github release along with tag. Naming convention for both ```v2.8.1```
